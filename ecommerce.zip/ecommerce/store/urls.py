from django.urls import path
from .views import login_view, logout_view, register, product_list, product_detail, cart_view, checkout_view, remove_from_cart, user_profile, search_results, cart_add  # Import cart_add explicitly

app_name = 'store'

urlpatterns = [
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('register/', register, name='register'),
    path('products/', product_list, name='product_list'),
    path('products/<int:product_id>/', product_detail, name='product_detail'),
    path('cart/', cart_view, name='cart'),
    path('checkout/', checkout_view, name='checkout'),
    path('remove-from-cart/<int:cart_item_id>/', remove_from_cart, name='remove_from_cart'),
    path('user/profile/', user_profile, name='user_profile'),
    path('search/', search_results, name='search_results'),
    path('cart/add/<int:product_id>/', cart_add, name='cart_add'),
]
