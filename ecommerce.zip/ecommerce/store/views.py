from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .models import Product, Order, CartItem
from .forms import RegistrationForm, LoginForm, AddToCartForm, SearchForm
from django.contrib import messages



def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('store:login')  # Updated redirect with namespace
    else:
        form = RegistrationForm()
    return render(request, 'store/register.html', {'form': form})

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages

def login_view(request):
    form = AuthenticationForm(request, data=request.POST or None)  # Using Django's built-in AuthenticationForm
    if request.method == 'POST':
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                return redirect('store:product_list')  # Redirect to a page after successful login
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Please correct the errors below.")
    
    return render(request, 'store/login.html', {'form': form})

def logout_view(request):  # Renamed function
    auth_logout(request)
    return redirect('store:login')  # Updated redirect with namespace


def product_list(request):
    products = Product.objects.all()
    return render(request, 'store/product_list.html', {'products': products})

def product_detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    if request.method == 'POST':
        form = AddToCartForm(request.POST)
        if form.is_valid():
            quantity = form.cleaned_data['quantity']
            order, created = Order.objects.get_or_create(user=request.user, completed=False)
            
            # Check if the item already exists in the cart
            cart_item, created = CartItem.objects.get_or_create(order=order, product=product)
            if not created:
                cart_item.quantity += quantity
            else:
                cart_item.quantity = quantity
            cart_item.save()
            return redirect('store:cart')  # Corrected redirect with the correct URL name
    else:
        form = AddToCartForm(initial={'product_id': product.id})
    return render(request, 'store/product_detail.html', {'product': product, 'form': form})

@login_required(login_url='/store/login/')

def cart_view(request):
    order = Order.objects.filter(user=request.user, completed=False).first()
    items = order.items.all() if order else []
    return render(request, 'store/cart.html', {'items': items, 'order': order})

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Product, Order, CartItem
from .forms import AddToCartForm


@login_required(login_url='/store/login/')
def checkout_view(request):
    order = Order.objects.filter(user=request.user, completed=False).first()
    
    # Set a default total_price
    total_price = 0
    
    if order:
        total_price = sum(item.get_total_price() for item in order.items.all())

        if request.method == 'POST':
            order.completed = True
            order.save()
            messages.success(request, "Purchase completed successfully!")
            return redirect('store:product_list')  # Redirect after purchase

    return render(request, 'store/checkout.html', {'order': order, 'total_price': total_price})

from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import CartItem
@login_required(login_url='/store/login/')
def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CartItem, id=cart_item_id, order__user=request.user, order__completed=False)
    cart_item.delete()
    messages.success(request, "Item has been removed from your cart.")
    return redirect('store:cart')
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required(login_url='/store/login/')
def user_profile(request):
    # You can add context or further logic as needed
    return render(request, 'store/user_profile.html')
from django.shortcuts import render
from .models import Product

def search_results(request):
    query = request.GET.get('query', '')
    products = Product.objects.filter(name__icontains=query)  # Adjust the filter based on your model attributes
    return render(request, 'store/search_results.html', {'products': products})
from django.shortcuts import redirect
from django.views.decorators.http import require_POST
from .models import Product, CartItem, Order

from django.shortcuts import get_object_or_404, redirect
from django.views.decorators.http import require_POST
from .models import Product, Order, CartItem
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect
from .models import Product, Order, CartItem
from .forms import AddToCartForm  # Ensure this form is defined

@require_POST

@login_required(login_url='/store/login/')
def cart_add(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    quantity = int(request.POST.get('quantity', 1))  # Default to 1 if not provided
    
    order, created = Order.objects.get_or_create(user=request.user, completed=False)
    cart_item, created = CartItem.objects.get_or_create(order=order, product=product)
    
    if not created:
        cart_item.quantity += quantity
    else:
        cart_item.quantity = quantity
    cart_item.save()
    
    return redirect('store:cart')
