from django.contrib import admin
from .models import Product, Order, CartItem

# Inline class to manage CartItems directly within Order view
class CartItemInline(admin.TabularInline):
    model = CartItem
    extra = 1

# Registering the Product model
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price')
    search_fields = ('name', 'description')

# Registering the Order model with CartItem inline
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at', 'completed')
    list_filter = ('completed',)
    search_fields = ('user__username',)
    inlines = [CartItemInline]  # Include CartItems in Order view

# Registering the CartItem model
@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ('product', 'order', 'quantity')
    search_fields = ('product__name',)
